#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 17:03:03 2021

@author: chloepoulic
"""
import skimage.io as skio
import imutils
import numpy as np
import cv2
from math import floor

def dim_rect(taille_im_x, taille_im_y, rectn_x, rectn_y):
    """
    Cette fonction permet de vérifier qu'un rectangle est de dimensions semblables à
    celles d'une case de la grille d'ailes.
    La vérification consiste à vérifier si la surface du rectangle relevée est dans 
    l'intervalle de confiance choisi.

    Parameters
    ----------
    taille_im_x : TYPE entier - donne la taille suivant les x du rectangle type
    taille_im_y : TYPE entier - donne la taille suivant les y du rectangle type
    rectn_x : TYPE entier - donne la taille suivant les x du rectangle relevé
    rectn_y : TYPE entier - - donne la taille suivant les y du rectangle relevé
    
    Returns
    -------
    True si le rectangle est satisfaisant, False sinon.

    """
    surface_im = taille_im_x*taille_im_y/14 #On divise par 14 car il y a 14 rectangles dans une grille
    surface_rectn = rectn_x*rectn_y
    if ((surface_im*1.2 > surface_rectn) and (surface_im*0.8 < surface_rectn) ):
        return True
    else:
        return False
    
    
    
def supp_in_tab_im_indice(tab_im_indice, img):
    """
    Cette fonction permet de récuperer uniquement les indices des rectangles qui sont
    bien aux dimensions de la grille.

    Parameters
    ----------
    tab_im_indice : TYPE tableau d'entiers
    img : TYPE image

    Returns
    -------
    La liste des indices des rectangles "bons".

    """
    tab_im_ok=[]
    taille_im_x = img.shape[0]
    taille_im_y = img.shape[1]
    for i in tab_im_indice:
        #pour chaque indice, on vérifie que le rectangle associé est de la bonne taille
        if dim_rect(taille_im_x, taille_im_y, i[1]-i[0], i[3]-i[2]):
            #C'est de la bonne taille on l'ajoute dans la liste des indices
            tab_im_ok.append(i)
    return tab_im_ok



def find_the_other(tab_im, img):
    """
    Cette fonction permet de récuperer les rectangles non détectés à partir de ceux 
    déjà trouvés.

    Parameters
    ----------
    tab_im : TYPE tableau d'entiers
    img : TYPE image
    
    Returns
    -------
    Tableau des indices des rectangles ainsi que leur décalage, pour la grille entière.
    tab_im_final possède 2 lignes (comme la grille) et 7 colonnes (comme la grille).
    La 5e dimension est liée au décalage induit lors de la recherche des autres rectangles
    par l'obtention d'un seul rectangle.
    """
    tab_im_final = np.zeros((2,7,5))                    #tableau final
    for i in range(2):
        for j in range(7):
            tab_im_final[i,j][0] = -1.
            tab_im_final[i,j][1] = -1.
            tab_im_final[i,j][2] = -1. 
            tab_im_final[i,j][3] = -1.  
            tab_im_final[i,j][4] = 20.                  #majoration du décalage par la valeur 20 (sachant que 6 max en réalité)
    tab_im_ok = supp_in_tab_im_indice(tab_im, img)      #suppression des "faux" rectangles
    
    len_x_im = img.shape[0]//2
    mid_y_im = img.shape[1]//7
        
    for i in range (0, len(tab_im_ok)):
        mid_x = (tab_im_ok[i][1]+tab_im_ok[i][0])//2    #détermination du milieu x d'un rectangle
        mid_y = (tab_im_ok[i][3]+tab_im_ok[i][2])//2    #détermination du milieu y d'un rectangle
        
        if mid_x > len_x_im:                
            #je me trouve en bas
            res = floor(mid_y/mid_y_im)                 #détermination de la case du rectangle (de 1 à 14)
            tab_im_final[1, res] = tab_im_ok[i]+[0]
            
        else :
            #je me trouve en haut
            res = floor(mid_y/mid_y_im)                 #détermination de la case du rectangle (de 1 à 14)
            tab_im_final[0, res] = tab_im_ok[i]+[0]
            
    return tab_im_final



def test_droite(tab_im_final, i, j):
    """
    Cette fonction vérifie que la case à droite de la notre est non vide pour lui ajouter un décalage ou non.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Le tableau avec l'indice de décalage mis à jour, ou 20 si nous avons une case vide à droite.
    """
    droite = tab_im_final[i,j+1]
    if (droite != [-1.,-1.,-1.,-1.,20.]).all():
        return tab_im_final[i,j+1][4]+1
    else:
        return 20



def changer_droite(tab_im_final, i, j):
    """
    Cette fonction prend les coordonnées du rectangle à droite du rectangle étudié, en tenant compte du décalage.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Met à jour le tableau final en ajoutant les bonnes coordonnées du nouveau rectangle trouvé.
    """
    largeur_y = tab_im_final[i,j+1][3] - tab_im_final[i,j+1][2]
    tab_im_final[i,j] = [tab_im_final[i,j+1][0], tab_im_final[i,j+1][1], tab_im_final[i,j+1][2]-largeur_y , tab_im_final[i,j+1][3]-largeur_y,tab_im_final[i,j+1][4]+1]
        
    
    
def test_gauche(tab_im_final, i, j):
    """
    Cette fonction vérifie que la case à gauche de la notre est non vide pour lui ajouter un décalage ou non.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Le tableau avec l'indice de décalage mis à jour, ou 20 si nous avons une case vide à gauche.
    """
    gauche = tab_im_final[i,j-1]
    if (gauche != [-1.,-1.,-1.,-1.,20.]).all():
        return tab_im_final[i,j-1][4]+1
    else:
        return 20



def changer_gauche(tab_im_final, i, j):
    """
    Cette fonction prend les coordonnées du rectangle à gauche du rectangle étudié, en tenant compte du décalage.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Met à jour le tableau final en ajoutant les bonnes coordonnées du nouveau rectangle trouvé.
    """
    largeur_y = tab_im_final[i,j-1][3] - tab_im_final[i,j-1][2]
    tab_im_final[i,j] = [tab_im_final[i,j-1][0], tab_im_final[i,j-1][1], tab_im_final[i,j-1][2]+largeur_y , tab_im_final[i,j-1][3]+largeur_y,tab_im_final[i,j-1][4]+1]
       
    
    
def test_bas(tab_im_final, i, j):
    """
    Cette fonction vérifie que la case en bas de la notre est non vide pour lui ajouter un décalage ou non.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Le tableau avec l'indice de décalage mis à jour, ou 20 si nous avons une case vide en base.
    """
    bas = tab_im_final[i+1,j]
    if (bas != [-1.,-1.,-1.,-1.,20.]).all():
        return tab_im_final[i+1,j][4]
    else:
        return 20



def changer_bas(tab_im_final, i, j):
    """
    Cette fonction prend les coordonnées du rectangle en bas du rectangle étudié, en tenant compte du décalage.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Met à jour le tableau final en ajoutant les bonnes coordonnées du nouveau rectangle trouvé.
    """
    hauteur_x = tab_im_final[i+1,j][1] - tab_im_final[i+1,j][0]
    tab_im_final[i,j] = [tab_im_final[i+1,j][0] - hauteur_x, tab_im_final[i+1,j][1] - hauteur_x, tab_im_final[i+1,j][2], tab_im_final[i+1,j][3],tab_im_final[i+1,j][4]]



def test_haut(tab_im_final, i, j):
    """
    Cette fonction vérifie que la case en haut de la notre est non vide pour lui ajouter un décalage ou non.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Le tableau avec l'indice de décalage mis à jour, ou 20 si nous avons une case vide en haut.
    """
    haut = tab_im_final[i-1,j]
    if (haut != [-1.,-1.,-1.,-1.,20.]).all():
        return tab_im_final[i-1,j][4]
    else:
        return 20



def changer_haut(tab_im_final, i, j):
    """
    Cette fonction prend les coordonnées du rectangle en haut du rectangle étudié, en tenant compte du décalage.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    i : TYPE entier
    j : TYPE entier
    
    Returns
    -------
    Met à jour le tableau final en ajoutant les bonnes coordonnées du nouveau rectangle trouvé.
    """
    hauteur_x = tab_im_final[i-1,j][1] - tab_im_final[i-1,j][0]
    tab_im_final[i,j] = [tab_im_final[i-1,j][0] + hauteur_x, tab_im_final[i-1,j][1] + hauteur_x, tab_im_final[i-1,j][2], tab_im_final[i-1,j][3],tab_im_final[i-1,j][4]]




def extract_missing_img(tab_im_final):
    for i in range(0,2):
        for j in range (0,7):
            #cas de nullité de im_final
            if (tab_im_final[i,j] == [-1.,-1.,-1.,-1.,20.]).all():
                reussite = 0
                meilleur = ""
                #soit à droite, à gauche ou en haut ou en bas il y a un dif de 0
                if i == 0:
                    if j == 0:
                        reussite = test_bas(tab_im_final, i, j)
                        if reussite < 20 :
                            meilleur = "bas"
                        if ( test_droite(tab_im_final, i, j) < reussite):
                            reussite = test_droite(tab_im_final, i, j)
                            if reussite < 20:
                                meilleur = "droite"
                                
                    elif j == 6:
                        reussite = test_bas(tab_im_final, i, j)
                        if (reussite < 20):
                            meilleur = "bas"
                        if (test_gauche(tab_im_final, i, j) < reussite):   
                            reussite = test_gauche(tab_im_final, i, j)
                            if reussite < 20:
                                meilleur = "gauche"
                    else :
                        reussite = test_bas(tab_im_final, i, j)
                        if (reussite < 20):
                            meilleur = "bas"
                        if (test_gauche(tab_im_final, i, j) < reussite):
                            reussite = test_gauche(tab_im_final, i, j)
                            if (reussite < 20 ):
                                meilleur = "gauche"
                        if (test_droite(tab_im_final, i, j) < reussite):
                            reussite = test_droite(tab_im_final, i, j)
                            if (reussite < 20):
                                meilleur = "droite" 
                    if meilleur == "bas":
                        changer_bas(tab_im_final, i, j)
                    elif meilleur == "droite":
                        changer_droite(tab_im_final, i, j)
                    elif meilleur == "gauche":
                        changer_gauche(tab_im_final, i, j)
                    elif meilleur == "haut":
                        changer_haut(tab_im_final, i, j)
                else :
                    if j == 0:
                        reussite = test_haut(tab_im_final, i, j)
                        if reussite < 20 :
                            meilleur = "haut"
                        if ( test_droite(tab_im_final, i, j) < reussite):
                            reussite = test_droite(tab_im_final, i, j)
                            if reussite < 20:
                                meilleur = "droite"
                                
                    elif j == 6:
                        reussite = test_haut(tab_im_final, i, j)
                        if (reussite < 20):
                            meilleur = "haut"
                        if (test_gauche(tab_im_final, i, j) < reussite):   
                            reussite = test_gauche(tab_im_final, i, j)
                            if reussite < 20:
                                meilleur = "gauche"
                    else :
                        reussite = test_haut(tab_im_final, i, j)
                        if (reussite < 20):
                            meilleur = "haut"
                        if (test_gauche(tab_im_final, i, j) < reussite):
                            reussite = test_gauche(tab_im_final, i, j)
                            if (reussite < 20 ):
                                meilleur = "gauche"
                        if (test_droite(tab_im_final, i, j) < reussite):
                            reussite = test_droite(tab_im_final, i, j)
                            if (reussite < 20):
                                meilleur = "droite"
                    if meilleur == "haut":
                        changer_haut(tab_im_final, i, j)
                    elif meilleur == "droite":
                        changer_droite(tab_im_final, i, j)
                    elif meilleur == "gauche":
                        changer_gauche(tab_im_final, i, j)
                    elif meilleur == "haut":
                        changer_haut(tab_im_final, i, j)
                        
                        
                        
                        
def enregistre_im(tab_im_final, image, nom_ranger):
    """
    Cette fonction enregistre les ailes découpées suivant le rectangle déterminé dans le fichier nom_ranger.

    Parameters
    ----------
    tab_im_final : TYPE tableau 
    img : TYPE img
    nom_ranger : TYPE adresse - adresse reltive ou complète du dossier où ranger les images
    
    Returns
    -------

    """
    for i in range(2):
        for j in range(7):
            if (tab_im_final[i,j] != [-1.,-1.,-1.,-1.,20.]).all():
                #à changer
                cv2.imwrite ( nom_ranger + '/z_test'+ str(i)+str(j) + '.jpg', image[int(tab_im_final[i,j][0]):int(tab_im_final[i,j][1]), int(tab_im_final[i,j][2]):int(tab_im_final[i,j][3]), :])



def decoupe(filename):
    """
    Cette fonction découpe en 14 images la grille initiale pour donner 14 images avec une seule aile par 
    image.

    Parameters
    ----------
    filename : TYPE adresse donnée par filedialog.askopenfilename lors de l'utilisation de l'application.
    
    Returns
    -------
    Met à jour le tableau final en ajoutant les bonnes coordonnées du nouveau rectangle trouvé.
    """
    image = skio.imread(filename)                           #chargement de l'image choisie
    ratio = image.shape[0] / 300.0                          
    image = imutils.resize(image, height = 300)             #redimensionnement de l'image, avec 300 pixels
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)          #conversion de l'image en niveau de gris
    gray = cv2.bilateralFilter(gray, 11, 17, 17)            #suppression du bruit dans l'image tout en préservant les bords réels
  
    #Suppression des potentielles bandes bleues sur les côtés, en haut et en bas
    gray[0:5,: ] = 0
    gray[-6:-1,: ] = 0
    gray[:,0:5] = 0
    gray[ : ,-6:-1 ] = 0
    
    edged = cv2.Canny(gray, 30, 200)                        #détection de contours
  
   
    cnts = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)       #trouver des contours de rectangles
    cnts = imutils.grab_contours(cnts)
    cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:10]                     #gère le tri de nos contours, du plus grand au plus petit, en calculant l'aire du contour à l'aide de cv2.contourArea
    screenCnt = None
    
    tab_im = []
    tab_im_indice = []
    for i in range (14):
        for c in cnts:                                      #boucler nos 10 plus grands contours dans l'image de requête
            #approchement du contour avec un niveau de précision de 1,7%
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.017 * peri, True)
    
            if len(approx) == 4:                            #vérification du nombre de points de notre contour approximatif, 4 c'est un rectangle
                screenCnt = approx
                break

        #On va gérer les exceptions, s'il y a une erreur à cause du fait que la forme
        #détectée n'est pas un rectangle, alors on ne va pas arreter l'algo car l'exception
        #vas être ensuite traitée comme un cas d'échec menant à un retour de la valeur None
        try:
            pts = screenCnt.reshape(4, 2)
        except AttributeError:                              #len(approx) != 4
            print('Pas de carrée ou de rectangle')
        else:
            #len(approx) == 4
            rect = np.zeros((4, 2), dtype = "float32")
            # le point en haut à gauche a la plus petite somme alors que le point
            # en bas à droite a la plus grande somme
            s = pts.sum(axis = 1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            # calculer la différence entre les points -- le point en haut à droite
            # aura la différence minimale et le point inférieur gauche aura la différence maximale
            # aura la différence maximale
            diff = np.diff(pts, axis = 1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]
            
            rect *= ratio
            # maintenant que nous avons notre rectangle de points, calculons
            # la largeur de notre nouvelle image
            (tl, tr, br, bl) = rect
            
            #On récupère les coordonnées des x et des y du rectangle
            x_0 = np.min(screenCnt[:,:,1])
            x_1 = np.max(screenCnt[:,:,1])
            y_0 = np.min(screenCnt[:,:,0])
            y_1 = np.max(screenCnt[:,:,0])
            
            tab_im.append(image[x_0:x_1, y_0:y_1, :])
            tab_im_indice.append([x_0,x_1, y_0,y_1])
    
            gray[x_0:x_1, y_0:y_1] = 10
            edged = cv2.Canny(gray, 30, 200)
            # trouver les contours dans l'image bordée, ne garder que les plus grands
            # les plus grands, et initialiser notre contour d'écran
            cnts = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            cnts = imutils.grab_contours(cnts)
            cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:1000]
        
        
    tab_im_final = find_the_other(tab_im_indice, image)     #trouver les autres rectangles
    if ((tab_im_final[0]==[-1.,-1.,-1.,-1.,20.]).sum()+(tab_im_final[1]==[-1.,-1.,-1.,-1.,20.]).sum())==70:
        return None
    else:
        #Tant qu'il y a des cases du tableau qui n'ont pas de coordonnée de rectangle 
        while (([-1.,-1.,-1.,-1.,20.] in tab_im_final[0]) or ([-1.,-1.,-1.,-1.,20.] in tab_im_final[1])):
            extract_missing_img(tab_im_final)
    return tab_im_final