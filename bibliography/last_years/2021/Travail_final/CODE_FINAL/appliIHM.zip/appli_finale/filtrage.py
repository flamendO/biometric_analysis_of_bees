import numpy as np
import time
import cv2
import skimage.io as skio

def aile_filtrage(filename, tab_im_final, nom_ranger):
   

    #--- Fonctions ---#

    def recherche_x_y(I,x_depart,y_depart,val_test,val_nouvelle):
        if I[x_depart,y_depart] == val_test:
            I[x_depart,y_depart] = val_nouvelle
            return(x_depart,y_depart)
        else:
            decalage_recherche = 1    
            while(True):
                if I[x_depart+decalage_recherche,y_depart] == val_test:
                    I[x_depart+decalage_recherche,y_depart] = val_nouvelle
                    return(x_depart+decalage_recherche,y_depart)
                elif I[x_depart-decalage_recherche,y_depart] == val_test:
                    I[x_depart-decalage_recherche,y_depart] = val_nouvelle
                    return(x_depart-decalage_recherche,y_depart)
                elif I[x_depart,y_depart+decalage_recherche] == val_test:
                    I[x_depart,y_depart+decalage_recherche] = val_nouvelle
                    return(x_depart,y_depart+decalage_recherche)
                elif I[x_depart,y_depart-decalage_recherche] == val_test:
                    I[x_depart,y_depart-decalage_recherche] = val_nouvelle
                    return(x_depart,y_depart-decalage_recherche)
                else:
                    decalage_recherche += 1

    def modifier_x_y_compteur(compteur):
        if compteur==0:
            return(round(l_max/2),round(c_max/2))
        elif compteur==1:
            return(round(l_max/2),round(c_max/2 + c_max/5))
        elif compteur==2:
            return(round(l_max/2 + l_max/5),round(c_max/2 + c_max/5))
        elif compteur==3:
            return(round(l_max/2 + l_max/5),round(c_max/2))
        elif compteur==4:
            return(round(l_max/2 + l_max/5),round(c_max/2 - c_max/5))
        elif compteur==5:
            return(round(l_max/2),round(c_max/2 - c_max/5))
        elif compteur==6:
            return(round(l_max/2 - l_max/5),round(c_max/2 - c_max/5))
        elif compteur==7:
            return(round(l_max/2 - l_max/5),round(c_max/2))
        elif compteur==8:
            return(round(l_max/2 - l_max/5),round(c_max/2 + c_max/5))
        else:
            return(round(l_max/2),round(c_max/2))

    def nettoyage_en_croix(I,l,c,d,val_reference):
        for i in range(l-d):
            for j in range(c-d):
                val_gauche_haute = I[i,j]
                val_droite_haute = I[i+d,j]
                val_gauche_bas = I[i,j+d]
                val_droite_bas = I[i+d,j+d]
                if val_gauche_haute == val_reference:
                    if val_gauche_haute == val_droite_haute:
                        for k in range(d-1):
                            I[i+k+1,j] = val_gauche_haute
                    if val_gauche_haute == val_gauche_bas:
                        for k in range(d-1):                    
                            I[i,j+k+1] = val_gauche_haute
                if val_droite_bas == val_reference:
                    if val_droite_haute == val_droite_bas:
                        for k in range(d-1):                    
                            I[i+d,j+k+1] = val_droite_haute
                    if val_gauche_bas == val_droite_bas:
                        for k in range(d-1):                    
                            I[i+k+1,j+d] = val_gauche_bas

    def coloriage_croix_liste(indice_x,indice_y,I,l,c,val_test,val_nouvelle,tous_les_bords_sont_noirs):
        L = [(indice_x,indice_y)]
        retour_trop_de_recursion=False
        if tous_les_bords_sont_noirs:
            while L != [] and retour_trop_de_recursion==False:
                (x_actuel,y_actuel) = L[-1]
                if x_actuel<=l/10 or x_actuel>=9/10*l or y_actuel<=c/10 or y_actuel==9/10 *c:
                    retour_trop_de_recursion=True
                else:
                    L = L[:-1]
                    if I[x_actuel+1,y_actuel]==val_test:
                        I[x_actuel+1,y_actuel]=val_nouvelle
                        L.append((x_actuel+1,y_actuel))
                    if I[x_actuel-1,y_actuel]==val_test:
                        I[x_actuel-1,y_actuel]=val_nouvelle
                        L.append((x_actuel-1,y_actuel))
                    if I[x_actuel,y_actuel+1]==val_test:
                        I[x_actuel,y_actuel+1]=val_nouvelle
                        L.append((x_actuel,y_actuel+1))
                    if I[x_actuel,y_actuel-1]==val_test:
                        I[x_actuel,y_actuel-1]=val_nouvelle
                        L.append((x_actuel,y_actuel-1))
            return retour_trop_de_recursion
        else:
            while L != [] and retour_trop_de_recursion==False:
                (x_actuel,y_actuel) = L[-1]
                if x_actuel==0 or x_actuel==l-1 or y_actuel==0 or y_actuel==c-1:
                    retour_trop_de_recursion=True
                else:
                    L = L[:-1]
                    if I[x_actuel+1,y_actuel]==val_test:
                        I[x_actuel+1,y_actuel]=val_nouvelle
                        L.append((x_actuel+1,y_actuel))
                    if I[x_actuel-1,y_actuel]==val_test:
                        I[x_actuel-1,y_actuel]=val_nouvelle
                        L.append((x_actuel-1,y_actuel))
                    if I[x_actuel,y_actuel+1]==val_test:
                        I[x_actuel,y_actuel+1]=val_nouvelle
                        L.append((x_actuel,y_actuel+1))
                    if I[x_actuel,y_actuel-1]==val_test:
                        I[x_actuel,y_actuel-1]=val_nouvelle
                        L.append((x_actuel,y_actuel-1))
            return retour_trop_de_recursion

    def coloriage_diag_liste(indice_x,indice_y,I,l,c,val_test,val_nouvelle):
        L = [(indice_x,indice_y)]
        while L != []:
            (x_actuel,y_actuel) = L[-1]
            L = L[:-1]
            if x_actuel<l-1:
                if I[x_actuel+1,y_actuel]==val_test:
                    I[x_actuel+1,y_actuel]=val_nouvelle
                    L.append((x_actuel+1,y_actuel))
            if x_actuel>0:
                if I[x_actuel-1,y_actuel]==val_test:
                    I[x_actuel-1,y_actuel]=val_nouvelle
                    L.append((x_actuel-1,y_actuel))
            if y_actuel<c-1:
                if I[x_actuel,y_actuel+1]==val_test:
                    I[x_actuel,y_actuel+1]=val_nouvelle
                    L.append((x_actuel,y_actuel+1))
            if y_actuel>0:
                if I[x_actuel,y_actuel-1]==val_test:
                    I[x_actuel,y_actuel-1]=val_nouvelle
                    L.append((x_actuel,y_actuel-1))
            if x_actuel<l-1 and y_actuel<c-1:
                if I[x_actuel+1,y_actuel+1]==val_test:
                    I[x_actuel+1,y_actuel+1]=val_nouvelle
                    L.append((x_actuel+1,y_actuel+1))
            if x_actuel>0 and y_actuel<c-1:
                if I[x_actuel-1,y_actuel+1]==val_test:
                    I[x_actuel-1,y_actuel+1]=val_nouvelle
                    L.append((x_actuel-1,y_actuel+1))
            if x_actuel<l-1 and y_actuel>0:
                if I[x_actuel+1,y_actuel-1]==val_test:
                    I[x_actuel+1,y_actuel-1]=val_nouvelle
                    L.append((x_actuel+1,y_actuel-1))
            if x_actuel>0 and y_actuel>0:
                if I[x_actuel-1,y_actuel-1]==val_test:
                    I[x_actuel-1,y_actuel-1]=val_nouvelle
                    L.append((x_actuel-1,y_actuel-1))

    #--- Main ---#

    

    
    # Parameters
    decalage = 5
    compteur_reussi = 0
    compteur_rate = 0
    t_debut = time.time()
    
    
    for m in range (0,2):
        for n in range (0,7):
            
            image_couleur_base = skio.imread(filename) #On étudie chaque aile
            
            base_shape = image_couleur_base.shape
            
            ratio = base_shape[0]/300                   # Dans la segmentation de l'aile on modifie l'échelle de l'image
        
            # Choix de la taille de l'image 
            x_debut= int(tab_im_final[m,n][0] * ratio)
            x_fin= int(tab_im_final[m,n][1] * ratio)
            y_debut= int(tab_im_final[m,n][2] * ratio)
            y_fin= int(tab_im_final[m,n][3] * ratio)
            
            
            # On vérifie avec les arrondis lors de la remise à l'échelle qu'on ne sort pas de l'image
            if x_debut < 0 :
                x_debut = 0
            if y_debut < 0 :
                y_debut = 0
            if x_fin >= base_shape[0]:
                x_fin = base_shape[0]-1
            if y_fin >= base_shape[1]:
                y_fin = base_shape[1]-1
            
            image_couleur = image_couleur_base[x_debut:x_fin,y_debut:y_fin]
            
            #On converti l'image en noir et blanc
            gray = image_couleur[:,:,0]*0.298 + image_couleur[:,:,1]*0.586 + image_couleur[:,:,2]*0.114
            gray = np.array(gray,dtype=np.uint8)
        
            
            binary = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,15,25)
            
            shape_image = binary.shape
            l_max = shape_image[0]
            c_max = shape_image[1]
            
            
            # la fonction qu'on appelle ensuite est optimisée pour s'arréter lorsque
            # on arrive sur un bord et qu'il est blanc, mais parfois les bandes de la segmentation vont rester noires
            # et donc on ne peut pas optimiser
            tous_les_bords_sont_noirs = True
            for i in range(0,l_max):
                if binary[i,0]==255 or binary[i,-1]==255:
                    tous_les_bords_sont_noirs = False
                    break
            for j in range(0,c_max):
                if binary[0,j]==255 or binary[-1,j]==255:
                    tous_les_bords_sont_noirs = False
                    break
        
            # On va étudier l'image binarire, mais si cela ne fonctionne pas
            # on aura besoin à nouveau de l'image initiale, on la garde donc en mémoire
            aile = np.array(binary,dtype=np.int16)
            reference = np.copy(aile)
        
        
            # On veut nettoyer une cellule(forme creuse de l'aile) de l'aile en y mettant que des pixels blancs sans les points noirs
            compteur=0
            not_succeed = True
            while(not_succeed):
                (x,y)= modifier_x_y_compteur(compteur) # On choisit un point de départ en espérant
                                                       # qu'il soit dans une cellule sinon on recommence
                                                       # avec un autre point de départ
            
                (x,y) = recherche_x_y(aile,x,y,255,256)  # On cherche un point blanc de l'image
                                                       # autour du point de départ et on change
                                                       # sa valeur de 255 à 256 (pour l'identifier)
        
        
                trop_de_recursion = coloriage_croix_liste(x,y,aile,l_max,c_max,255,256,tous_les_bords_sont_noirs) # Si un point à 255 est collé 
                                                                  # à un point vallant 256 il vaut
                                                                  # alors 256
                                                                  # Donc toute la cellule aura des
                                                                  # points vallant soit 0 soit 256
            
                if trop_de_recursion==False :                      # Permet de vérifier qu'on a colorié une cellule et
                                                                   # non le fond de l'image (perte d'information)
                    not_succeed = False
                    rate = False
                    nettoyage_en_croix(aile,l_max,c_max,decalage,256) # si on a             256  ?   ?   ?  256
                                                                      # alors on modifie en 256 256 256 256 256
                                                                      # de même en vertical
        
                    (x,y)= modifier_x_y_compteur(compteur)
                else:                              # Si on a nettoyé le fond on recommence avec un nouveau
                                                   # point de départ
                    compteur+=1
                    aile = np.copy(reference)
        
                if compteur>8:                      # Si on a toujours pas trouvé de cellule alors on arrête
                                                    # et le filtrage est raté
                    not_succeed = False
                    rate = True
                    
            if rate == False:                   # Si on a réussi le filtrage, on va chercher un point noir
                                                # de l'aile
                     
                for i in range(l_max):          # On remet les points qui valent 256 à 255
                    for j in range(c_max):
                        if aile[i,j]>255:
                            aile[i,j]=255
        
                aile_cellule_blanche = np.copy(aile)
        
                (x,y) = recherche_x_y(aile_cellule_blanche,x,y,0,-1) # On recherche un point noir en partant de la cellule nettoyée
                                                   # ce sera alors un point de l'aile et on le met à -1 
                                                   # pour l'identifier
                                               
                coloriage_diag_liste(x,y,aile_cellule_blanche,l_max,c_max,0,-1) # Si un point à 0 est collé 
                                                              # à un point vallant -1 il vaut alors -1
                                                              # donc tous les points de l'aile sont à -1  
        
                for i in range(l_max):                      # Les points toujours à 0 sont donc du bruit
                    for j in range(c_max):                  # on les mets à 255 (blanc)
                        if aile_cellule_blanche[i,j] == 0:
                            aile_cellule_blanche[i,j] = 255
                    
                for i in range(l_max):                      # On mets les points de l'aile : -1 à 0
                    for j in range(c_max):
                        if aile_cellule_blanche[i,j] == -1:
                            aile_cellule_blanche[i,j] = 0
                    
            
                
                cv2.imwrite(nom_ranger+'/z_test'+ str(m)+str(n) + '_reussi' + '.jpg',aile_cellule_blanche)
                compteur_reussi += 1
                
            else :
                cv2.imwrite(nom_ranger+'/z_test'+ str(m)+str(n) + '_rate' + '.jpg',image_couleur)
                compteur_rate += 1
    
    
    
    t_fin = time.time()
    print('Durée étape de filtrage : '+str(round(t_fin-t_debut,2))+' s, avec ' +str(compteur_reussi)+ ' ailes bien filtrées et ' +str(compteur_rate)+ ' ailes non filtrées.')