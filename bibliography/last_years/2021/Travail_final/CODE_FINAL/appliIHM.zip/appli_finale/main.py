#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 20:48:34 2021

@author: chloepoulic
"""
import tkinter as tk
from tkinter import PhotoImage, Canvas, filedialog, messagebox
from decoupage import decoupe
from filtrage import aile_filtrage

def change_page () :
    """
    Cette fonction détruit la première page racine et en crée une nouvelle appelée traitement fenetre.

    Parameters
    ----------
    racine : TYPE fenetre
    play_button : TYPE bouton

    Returns
    -------

    """
    global play_button, racine
    #destruction de la première fenetre et construction de la nouvelle
    racine.destroy()
    traitement_fenetre = tk.Tk() 
    traitement_fenetre.geometry("1080x720")
    traitement_fenetre.title("BeeAPI")
    traitement_fenetre.minsize(480, 360)
    traitement_fenetre.iconbitmap('deco/icone.ico')
    traitement_fenetre.config(background = '#FFCC66') 
    #définition de la liste d'instruction et de la photo représentative des résultats
    liste_instructions(traitement_fenetre)


def liste_instructions(fen):  
    """
    Cette fonction permet de mettre le titre, la liste d'instruction, l'image des résultats et
    l'implémentation du bouton qui permet de chercher l'image dans l'ordinateur personnel

    Parameters
    ----------
    fen : TYPE fenetre
    
    Returns
    -------

    """
    #Création du titre 
    titre = tk.Label(fen, text ="Instructions", font = "arial 45 bold", bg = "#FFCC66")
    titre.pack(side = tk.TOP)
    
    #Création de la liste
    txt = "Lorsque vous allez appuyer sur le bouton 'Commencer pour de bon cette fois-ci', vous allez devoir choisir l'image à traiter.\nElle doit se nommer sous la forme.\nEnsuite le traitement se fera automatiquement, et au moindre problème une instruction vous sera communiquée.\n Les résultats seront fournis comme sur l'image ci-contre.\nBonne expérience!"
    instruc= tk.Label(fen, text =txt, font = "arial 17 bold", bg = "#FFCC66", wraplength = 400, justify = tk.LEFT)
    instruc.pack(side = tk.LEFT)
    
    #Mise en place de la photo d'exemple
    
    #to do

    
    #Création du bouton commencer apres les instructions
    play_button_2 = tk.Button(fen, text = 'Commencer pour de bon cette fois-ci !', font = "arial 15 bold", bg = "#FFCC66", bd = 0, highlightthickness = 0)
    play_button_2.pack(side = tk.BOTTOM)
    play_button_2.config (command = give_path)
    


def give_path():
    """
    Donner le lieu de l'image à traiter, découpe l'image, si l'image est correctement découpée,
    exécuter le filtrage des ailes, sinon affiche un message d'erreur, et reste sur la même page
    pour pouvoir traiter une autre image.


    Parameters
    ----------
    play_button_2 : TYPE bouton
       

    Returns
    -------
    None.

    """
    global play_button_2
    filename =  filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*"),("png files","*.png")))
    tab_im_final = decoupe(filename)
    if (tab_im_final is None):
        messagebox.showerror(title= "Error", message= "Traitement de cette image impossible")
    else:
        aile_filtrage(filename, tab_im_final, '/Users/chloepoulic/Documents/BZZZZ_final/stockage')
        messagebox.showinfo(title= "Info", message= "Traitement de l'image réussi")


#debut du code, création de la fenêtre principale
racine = tk.Tk()  
  
#définition de la fenetre principale
racine.geometry("1080x720")             #dimensionne la taille de la fenêtre
racine.title("BeeAPI")
racine.minsize(480, 360)                #dimensionne la taille de la fenêtre minimale
racine.iconbitmap("deco/icone.ico")          #mettre un icone sur la barre
racine.config(background = '#FFCC66')   #changer la couleur
  

#Bouton pour lancer l'appli (puis les instructions, puis le choix de l'image à traiter, puis donne le chemin)
#définition du cadre pour placer le bouton et l'image
frame_app_start= tk.Frame(racine, bg = '#FFCC66')           
width = 400
height = 200
#import de l'image et positionnement
image = PhotoImage(file = 'deco/fond.png')
canvas = Canvas(frame_app_start, width=width, height = height, bg = "#FFCC66", bd = 0, highlightthickness = 0)
canvas.create_image(width/2, height/2, image = image)
canvas.pack(expand = tk.YES)
#import du bouton et association de clic avec une fonction qui change de page
play_button = tk.Button(frame_app_start, text = 'Commencer le traitement', font = "arial 15 bold", bg = "#FFCC66", bd = 0, highlightthickness = 0)
play_button.pack(expand = tk.YES, pady = 25)
play_button.config (command = change_page)
frame_app_start.pack(expand = tk.YES)


racine.mainloop()




